Pratica 00 - Monolitica

Autor: Asier Vega Gutierrez

Se entrega:
	- directorio 'src': codigo de la practica
	- directorio 'doc': capturas, video y trazas de la aplicacion en ejecucion